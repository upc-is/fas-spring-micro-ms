package pe.edu.upc.prueba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
